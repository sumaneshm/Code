﻿using CommonLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public interface IBusinessLogic
    {
        void Add(ManagableElement element);
        void Edit(ManagableElement element);
    }

    public interface IBusinessLogic<in T> : IBusinessLogic
    {
        void Add(T element);
        void Edit(T element);
    }
}
