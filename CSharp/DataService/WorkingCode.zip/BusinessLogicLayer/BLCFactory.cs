﻿using CommonLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    static class BLCFactory
    {
        public static IBusinessLogic GetBLC(ManagableElement element) 
        {
            switch(element.GetType().Name)
            {
                case "Employee":
                    return new EmployeeBLC();
                case "Student":
                    return new StudentBLC();
            }

            throw new ArgumentException("Unrecognized element");
        }
    }
}
