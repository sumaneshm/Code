﻿using CommonLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    interface IBusinessLogic
    {
        void Add(ManagableElement element);
        void Edit(ManagableElement element);
    }
}
