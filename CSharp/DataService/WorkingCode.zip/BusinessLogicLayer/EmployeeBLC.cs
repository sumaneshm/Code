﻿using CommonLibrary;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    class EmployeeBLC : IBusinessLogic
    {

        public void Add(ManagableElement element)
        {
            Employee e = element as Employee;
            EmployeeDAC dac = new EmployeeDAC();

            dac.Add(e);
            
        }

        public void Edit(ManagableElement element)
        {
            Employee e = element as Employee;
            EmployeeDAC dac = new EmployeeDAC();

            dac.Edit(e);
        }
    }
}
